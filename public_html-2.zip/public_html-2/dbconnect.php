<?php

$db = mysqli_connect("localhost",  "id17130795_byker",  "Danielkomolafe00%",  "id17130795_energymeter");

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}

?>



 