 
 <?php
 

    
  $token = 70;
        
      
  $db = mysqli_connect("localhost",  "id17130795_byker",  "Danielkomolafe00%",  "id17130795_energymeter");
  
  //$meter_no = "id17130795_energymeter";
  
  if (isset($_POST['check'])) {
  	 
  	$meter_no = $_POST['meter_no'];

  	$sql = "SELECT * FROM meter WHERE meterid='$meter_no'";
  	$res = mysqli_query($db, $sql);

  	if (mysqli_num_rows($res) > 0) {
  	echo "found"; 	
  	} 
  	else{
    echo $meter_no.' does not exist';
    exit();
  	}
  }
  
  
    if (isset($_POST['STS'])) {
  	 
  	$meter_no = $_POST['meter_no'];

   
    $servername = "localhost";
    $dbname = "id17130795_energymeter";
    $username = "id17130795_byker";
    $password = "Danielkomolafe00%"; 
     
    $con=mysqli_connect($servername, $username,  $password, $dbname) or die("Database Error");   
    if (!$con) {
    echo "Unable to connect to DB: " . mysql_error();
    exit;
    }

    $sql = "SELECT * from meter WHERE meterid='$meter_no'";
    $result = mysqli_query( $con ,$sql);
    $output= (mysqli_fetch_assoc($result));	
    
    $MT = $output['meterid'];
    $topup = $output['amount'];
    $transaction = $output['transaction_id'];
    $t=time();
    //echo(date("Y-m-d",$t)); 
    
    
    // sts token generation formular // 
    $mt_no = substr($MT,2, 10);
    $encode= $mt_no + $topup ;
    //echo $transaction; 
    //echo $mt_no;
    //echo $topup;
    //echo(date("md",$t)); 
    //echo $encode;
    //echo $token;
    mysqli_close($con);
    
   
   
  }
?>



<!DOCTYPE html>
<html>
  <head>
    

 <style>
        /* Container holding the image and the text */
.container {
  position: relative;
  text-align: center;
  //color: white;
   
}

/* Bottom left text */
.bottom-left {
  position: absolute;
  bottom: 8px;
  left: 16px;
}

/* Top left text */
.top-left {
  position: absolute;
  top: 8px;
  left: 16px;
}

/* Top right text */
.top-right {
  position: absolute;
  top: 8px;
  right: 16px;
}

/* Bottom right text */
.bottom-right {
  position: absolute;
  bottom: 8px;
  right: 16px;
}

/* Centered text */
.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 250%;
  color: white;
  font-family: "Times New Roman", Times, serif;
  //font-family: Arial, Helvetica, sans-serif;
}
</style>
</head>
  
<body>
    
    <div class="container">
  <img src="img/sts2.jpg" alt="Snow" style="width:100%;">
   
  <div class="centered"> <?php 
  //echo $transaction; 
  //echo(date("md",$t)); 
  $time_base = (date("md",$t)); 
  //echo $encode;
  //echo $token; 
  $all = $transaction.$time_base.$encode.$token; 
  $length = strlen($all);
  if($length>9){
  echo $all;
  }
  else if($length<9){
  echo "Sorry Meter does not exist";    
  }
  ?></div>
</div>
    
  </body>
  
</html>