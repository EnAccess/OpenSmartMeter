<?php

    echo " Establishing connecion with meter, response will popout in 20sec ";
  
    $meter =  ($_POST["meter_no"]);
    $servername = "localhost";
    $dbname = "id17130795_energymeter";
    $username = "id17130795_byker";
    $password = "Danielkomolafe00%";
 
    $conn = mysqli_connect ($servername, $username, $password, $dbname);
    //Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    $sql = "UPDATE meter SET  conn_status='' WHERE meterid='$meter'";
    if ($conn->query($sql) === TRUE) {
    //echo "sucess";
    } 
    else {
    echo "Error " . $conn->error;
    }
    $conn->close();    
  
  
    
     
    function recheckDB() { 
    $meter =  ($_POST["meter_no"]);
    $servername = "localhost";
    $dbname = "id17130795_energymeter";
    $username = "id17130795_byker";
    $password = "Danielkomolafe00%";
    $con=mysqli_connect($servername, $username,  $password, $dbname) or die("Database Error");   
    if (!$con) {
    echo "Unable to connect to DB: " . mysql_error();
    exit;
    }
    $sql = "SELECT * from meter WHERE meterid='$meter'";
    $result = mysqli_query( $con ,$sql);
    $output= (mysqli_fetch_assoc($result));	
    $status = $output['conn_status'];
    
    if($status == "sucess"){
    echo $meter." is active and online";    
    }
    if($status == ""){
    echo "unfortunately,"." ".$meter." did not respond"; 
    }
    mysqli_close($con);
    }
   ?>
   <script type="text/JavaScript"> 
   setTimeout(function(){
   alert("<?php   recheckDB(); ?>")
   },20000);
   </script>
